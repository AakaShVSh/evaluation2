const express = require("express");
const userSchema = require("../models/user.schema");
const s = require("../models/user.schema")
const app = express();

let see = async (req,res) => {

    try {
        const user = await userSchema.create();
        return res.send(user)
    } catch (error) {
        return res.send({error:error.message})
    }
}

module.exports = see;