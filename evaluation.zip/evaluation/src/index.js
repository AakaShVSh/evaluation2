const express =require("express");
const connect = require("./configs/db");
const usercontroller = require("./controllers/user.controller");
const userschema = require("./models/user.schema")
const usre = require("./controllers/usre")
const app = express();
app.use(express.json());
app.use("/user",usercontroller);
app.post("/user", usre)
app.listen(5000, async () => {
    try {
        await connect();
        console.log("this is running on portal 5000")
    } catch (error) {
        console.log({error:error.message});
    }
})
